package me.jiyun.myapplication;

/**
 * Created by JIYUN on 2017. 6. 11..
 */

public class Data {
    private String jsondata;

    public String getJsondata(){
        return jsondata;
    }

    public void setJsondata(String jsondata) {
        this.jsondata = jsondata;
    }

    @Override
    public String toString(){
        // 데이터가 보내지는 양식
        // 예시로, return "Data [data=" + jsondata + "]"; 이런식으로도 쓸 수 있다
        return jsondata;
    }
}
